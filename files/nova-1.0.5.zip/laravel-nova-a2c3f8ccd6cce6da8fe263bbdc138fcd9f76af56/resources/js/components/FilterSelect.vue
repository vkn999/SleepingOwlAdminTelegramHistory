<template>
    <div>
        <slot name="default"></slot>

        <div class="p-3">
            <slot name="select"></slot>
        </div>
    </div>
</template>

<script>
export default {}
</script>
