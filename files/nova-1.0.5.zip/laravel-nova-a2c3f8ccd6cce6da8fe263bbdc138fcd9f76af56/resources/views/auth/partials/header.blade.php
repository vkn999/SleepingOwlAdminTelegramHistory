<div class="mx-auto py-8 max-w-sm text-center text-90">
    @include('nova::auth.partials.logo')
</div>
