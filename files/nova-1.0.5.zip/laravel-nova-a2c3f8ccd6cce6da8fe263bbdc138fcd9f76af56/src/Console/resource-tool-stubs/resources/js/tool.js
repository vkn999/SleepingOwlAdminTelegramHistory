Nova.booting((Vue, router) => {
    Vue.component('{{ component }}', require('./components/Tool'));
})
