<?php

namespace Laravel\Nova\Fields;

class MorphMany extends HasMany
{
    //
}
