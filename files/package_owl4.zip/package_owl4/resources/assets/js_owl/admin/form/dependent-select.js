Admin.Modules.register('form.elements.dependent-select', () => {
    $('.input-select-dependent').depdrop()
}, 0, ['bootstrap::tab::shown'])