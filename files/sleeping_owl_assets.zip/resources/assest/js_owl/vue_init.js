const app = new Vue({
    el: '#vueApp'
});